const grid = document.getElementById('documents-grid');
const sortButtons = document.querySelectorAll('.documents-filters button');

document
  .querySelector('.documents-filters button[data-sort="new"]')
  ?.classList.add('active');

let currentSort = 'new';
let activeMode = null; // null | 'create' | 'edit'


/* =========================
   ЗАГРУЗКА ДОКУМЕНТОВ
========================= */
async function loadDocuments() {
    let url = '/api/documents';

    if (currentSort !== 'new') {
        url += `?sortBy=${currentSort}`;
    }

    const res = await fetch(url);
    const documents = await res.json();

    renderDocuments(documents);
}


/* =========================
   РЕНДЕР
========================= */
function renderDocuments(documents) {
    grid.innerHTML = '';

    documents.forEach(doc => {
        const card = document.createElement('div');
        card.className = 'document-card';

        card.innerHTML = `
            <div class="document-date">
                ${new Date(doc.uploadDate).toLocaleDateString()}
            </div>

            <div class="document-name">
                ${doc.name}
            </div>

            <div class="document-filename">
                ${doc.fileName.split('-').slice(1).join('-')}
            </div>

            <div class="document-actions-row">
                <button class="document-btn document-btn-primary"
                        onclick="editDocument(${doc.id}, this)">
                    Редактировать
                </button>

                <button class="document-btn document-btn-outline"
                        onclick="deleteDocument(${doc.id})">
                    Удалить
                </button>
            </div>

            <button class="document-btn document-btn-wide"
                    onclick="downloadFile('${doc.fileName}')">
                Скачать
            </button>
        `;

        grid.appendChild(card);
    });
}


/* =========================
   СОРТИРОВКА
========================= */
sortButtons.forEach(btn => {
    btn.addEventListener('click', () => {
        if (activeMode) return;

        sortButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        currentSort = btn.dataset.sort.toLowerCase();
        loadDocuments();
    });
});


/* =========================
   СКАЧИВАНИЕ
========================= */
function downloadFile(fileName) {
    window.location.href = `/download/${fileName}`;
}


/* =========================
   УДАЛЕНИЕ
========================= */
async function deleteDocument(id) {
    if (activeMode) return;
    if (!confirm('Удалить документ?')) return;

    await fetch(`/api/documents/${id}`, { method: 'DELETE' });
    loadDocuments();
}


/* =========================
   РЕДАКТИРОВАНИЕ (INLINE)
========================= */
async function editDocument(id, btn) {
    if (activeMode) return;
    activeMode = 'edit';

    const card = btn.closest('.document-card');

    const res = await fetch(`/api/documents/${id}`);
    const doc = await res.json();

    const originalHTML = card.innerHTML;

    card.innerHTML = `
        <input
            type="text"
            class="document-input"
            id="edit-name-${id}"
            value="${doc.name}"
        >

        <input
            type="file"
            class="document-input"
            id="edit-file-${id}"
        >

        <div class="document-current-file" id="current-file-${id}">
            Текущий файл: ${doc.fileName.split('-').slice(1).join('-')}
        </div>

        <div class="document-actions">
            <button class="document-btn document-btn--save">
                Сохранить
            </button>
            <button class="document-btn document-btn--cancel">
                Отмена
            </button>
        </div>
    `;

    const fileInput = card.querySelector(`#edit-file-${id}`);
    const fileLabel = card.querySelector(`#current-file-${id}`);

    // если пользователь выбирает новый файл — обновляем текст
    fileInput.addEventListener('change', () => {
        if (fileInput.files[0]) {
            fileLabel.textContent = `Выбран файл: ${fileInput.files[0].name}`;
        }
    });

    const saveBtn = card.querySelector('.document-btn--save');
    const cancelBtn = card.querySelector('.document-btn--cancel');

    cancelBtn.addEventListener('click', () => {
        card.innerHTML = originalHTML;
        activeMode = null;
    });

    saveBtn.addEventListener('click', async () => {
        const newName = card.querySelector(`#edit-name-${id}`).value.trim();
        const file = fileInput.files[0];

        if (!newName) {
            alert('Введите название документа');
            return;
        }

        const updateData = {
            name: newName,
            fileName: doc.fileName,
            fileType: doc.fileType,
            filePath: doc.filePath
        };

        if (file) {
            const formData = new FormData();
            formData.append('file', file);

            const uploadRes = await fetch('/upload', {
                method: 'POST',
                body: formData
            });

            const uploadData = await uploadRes.json();

            updateData.fileName = uploadData.fileName;
            updateData.fileType = file.name.split('.').pop().toUpperCase();
            updateData.filePath = `uploads/${uploadData.fileName}`;
        }

        await fetch(`/api/documents/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updateData)
        });

        activeMode = null;
        loadDocuments();
    });
}


/* =========================
   СОЗДАНИЕ
========================= */
const openBtn = document.getElementById('open-create-form');
const form = document.getElementById('create-form');
const cancelBtn = document.getElementById('cancel-create');

if (openBtn && form) {
    openBtn.addEventListener('click', () => {
        if (activeMode) return;

        activeMode = 'create';
        form.style.display = 'flex';
        openBtn.style.display = 'none';

        if (!grid.contains(form)) {
            grid.appendChild(form);
        }
    });
}

if (cancelBtn && form) {
    cancelBtn.addEventListener('click', () => {
        form.style.display = 'none';
        openBtn.style.display = 'inline-block';
        activeMode = null;

        if (grid.contains(form)) {
            grid.removeChild(form);
        }

        document.getElementById('new-name').value = '';
        document.getElementById('new-file').value = '';
    });
}

document.getElementById('create-btn').addEventListener('click', async () => {
    if (activeMode !== 'create') return;

    const name = document.getElementById('new-name').value.trim();
    const fileInput = document.getElementById('new-file');
    const file = fileInput.files[0];

    if (!name || !file) {
        alert('Заполните имя и выберите файл');
        return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
        // 1. Сначала загружаем файл
        const uploadRes = await fetch('/upload', {
            method: 'POST',
            body: formData
        });

        if (!uploadRes.ok) {
            throw new Error('Ошибка загрузки файла');
        }

        const uploadData = await uploadRes.json();

        // 2. Создаем запись о документе
        const documentData = {
            name,
            fileName: uploadData.fileName,
            fileType: file.name.split('.').pop().toUpperCase(),
            filePath: `uploads/${uploadData.fileName}`
        };

        const createRes = await fetch('/api/documents', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(documentData)
        });

        if (!createRes.ok) {
            throw new Error('Ошибка создания документа');
        }

        // 3. Очищаем форму
        document.getElementById('new-name').value = '';
        fileInput.value = '';

        // 4. Скрываем форму
        form.style.display = 'none';
        openBtn.style.display = 'inline-block';

        if (grid.contains(form)) {
            grid.removeChild(form);
        }

        // 5. Сбрасываем режим
        activeMode = null;

        // 6. Загружаем обновленные документы
        await loadDocuments();

    } catch (error) {
        console.error('Ошибка создания документа:', error);
        alert('Не удалось создать документ: ' + error.message);
        // Не сбрасываем activeMode при ошибке, чтобы пользователь мог попробовать снова
    }
});


/* =========================
   ИНИЦИАЛИЗАЦИЯ
========================= */
loadDocuments();
