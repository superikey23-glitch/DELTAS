// app.js
// список фраз для ежедневного сообщения
const dailyMessages = [
    "Сегодня отличный день, чтобы заработать миллион долларов.",
    "Сегодня отличный день, чтобы стать волшебником.",
    "Сегодня отличный день, чтобы напомнить близким, как вы их любите.",
    "Сегодня отличный день, чтобы создать новый химический элемент.",
    "Сегодня отличный день, чтобы работать с хорошим настроением.",
    "Сегодня отличный день, чтобы начать маленькое великое дело.",
    "Сегодня отличный день, чтобы придумать что-то гениальное.",
    "Сегодня отличный день, чтобы научиться чему-то новому.",
    "Сегодня отличный день, чтобы подумать нестандартно.",
    "Сегодня отличный день, чтобы просто быть молодцом.",
    "Сегодня отличный день, чтобы делать всё легко.",
    "Сегодня отличный день, чтобы придумать новый праздник.",
    "Сегодня отличный день, чтобы сделать мир капельку лучше.",
    "Сегодня отличный день, чтобы ничего не откладывать.",
    "Сегодня отличный день, чтобы поймать удачу за хвост.",
    "Сегодня отличный день, чтобы улучшить что-то хотя бы на 1%.",
    "Сегодня отличный день, чтобы улыбнуться.",
    "Сегодня отличный день, чтобы порадовать себя.",
    "Сегодня отличный день, чтобы вспомнить, что всё возможно.",
    "Сегодня отличный день, чтобы удивить самого себя.",
    "Сегодня отличный день, чтобы проявить талант.",
    "Сегодня отличный день, чтобы придумать новую традицию.",
    "Сегодня отличный день, чтобы действовать смело.",
    "Сегодня отличный день, чтобы сделать доброе дело.",
    "Сегодня отличный день, чтобы начать новую игру.",
    "Сегодня отличный день, чтобы создать что-то красивое.",
    "Сегодня отличный день, чтобы чуть-чуть отдохнуть.",
    "Сегодня отличный день, чтобы быть добрее к себе.",
    "Сегодня отличный день, чтобы закончить начатое.",
    "Сегодня отличный день, чтобы начать что-то новое."
];

// API URL для задач
const API_URL = 'http://localhost:3000/api/tasks';
let currentSort = 'new';

// функция для выбора случайной фразы
function getRandomMessage() {
    const today = new Date();
    const dayOfMonth = today.getDate();
    const index = dayOfMonth % dailyMessages.length;
    return dailyMessages[index];
}

// основная функция для загрузки данных
function loadData() {
    // 1. установить ежедневное сообщение
    const dailyMessageElement = document.getElementById('daily-message');
    if (dailyMessageElement) {
        dailyMessageElement.textContent = getRandomMessage();
    }
    
    // 2. загрузить объявление от админа
    const announcementElement = document.getElementById('admin-announcement');
    if (announcementElement) {
        // Здесь можно добавить загрузку реального объявления с сервера
        console.log('Загрузка объявления от админа...');
    }
    
    // 3. настроить кнопки скачивания (если они есть на странице)
    const downloadButtons = document.querySelectorAll('.download-button');
    downloadButtons.forEach(button => {
        button.addEventListener('click', function() {
            const fileName = this.getAttribute('data-file') || 'document.pdf';
            downloadFile(fileName);
        });
    });
    
    // 4. настроить ссылки в подвале
    const footerLinks = document.querySelectorAll('.footer-nav-button, .privacy-link');
    footerLinks.forEach(link => {
        if (link.href.includes('#')) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                alert(`Переход на страницу: ${this.textContent}`);
            });
        }
    });
    
    // 5. настроить кнопки в шапке
    const headerButtons = document.querySelectorAll('.action-button');
    headerButtons.forEach(button => {
        if (button.href.includes('notifications.html') || button.href.includes('profile.html')) {
            // реальные ссылки - оставляем как есть
        } else if (button.href.includes('#')) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                alert(`Нажата кнопка: ${this.textContent}`);
            });
        }
    });
    
    // 6. Загрузить задачи для главной страницы (превью)
    loadTasksPreview();
}

// Загрузка задач для главной страницы (последние 3 задачи)
// Загрузка задач для главной страницы (ближайшие по дедлайну)
async function loadTasksPreview() {
    try {
        // Используем сортировку по дедлайну с сервера
        const response = await fetch(`${API_URL}?sortBy=deadline`);
        const tasks = await response.json();
        const tasksPreview = document.getElementById('tasksPreview');
        
        if (tasksPreview) {
            // Берем первые 3 задачи (уже отсортированы сервером)
            const recentTasks = tasks.slice(0, 3);
            
            if (recentTasks.length === 0) {
                tasksPreview.innerHTML = '<p>Нет задач с дедлайном</p>';
                return;
            }
            
            // Формируем HTML с количеством дней до дедлайна
            tasksPreview.innerHTML = `
                <div class="tasks-container">
                    ${recentTasks.map(task => {
                        let daysText = '';
                        if (task.deadline) {
                            const deadlineDate = new Date(task.deadline);
                            const today = new Date();
                            today.setHours(0, 0, 0, 0); // Сбрасываем время для точного расчета дней
                            deadlineDate.setHours(0, 0, 0, 0);
                            
                            const daysDiff = Math.ceil((deadlineDate - today) / (1000 * 60 * 60 * 24));
                            
                            if (daysDiff === 0) daysText = '(сегодня)';
                            else if (daysDiff === 1) daysText = '(завтра)';
                            else if (daysDiff === -1) daysText = '(вчера)';
                            else if (daysDiff < 0) daysText = `(${Math.abs(daysDiff)} дн. назад)`;
                            else daysText = `(${daysDiff} дн.)`;
                        }
                        
                        return `
                            <div class="task-item">
                                <span class="task-bullet"></span>
                                <p class="task-text">${task.title} ${daysText}</p>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
        }
    } catch (error) {
        console.error('Ошибка загрузки задач для превью:', error);
        const tasksPreview = document.getElementById('tasksPreview');
        if (tasksPreview) {
            tasksPreview.innerHTML = '<p>Ошибка загрузки задач</p>';
        }
    }
}
// Функции для страницы tasks.html
async function loadTasks() {
    try {
        const response = await fetch(`${API_URL}?sortBy=${currentSort}`);
        const tasks = await response.json();
        renderTasks(tasks);
    } catch (error) {
        console.error('Ошибка загрузки задач:', error);
        alert('Не удалось загрузить задачи');
    }
}

function renderTasks(tasks) {
    const tasksGrid = document.getElementById('tasksGrid');
    if (!tasksGrid) return;

    tasksGrid.innerHTML = '';

    tasks.forEach(task => {
        const taskCard = createTaskCard(task, false);
        tasksGrid.appendChild(taskCard);
    });

    // Создаём карточку для новой задачи, если она ещё не создана
    const newTaskCard = createTaskCard({}, true);
    tasksGrid.appendChild(newTaskCard);  // Добавляем карточку для новой задачи в конец списка
}


function createTaskCard(task, isNew = false) {
    const card = document.createElement('div');
    card.className = 'task-card';
    card.dataset.id = task.id || 'new';

    if (isNew) {
        card.classList.add('new-task-card');
        card.innerHTML = `
            <div class="card-inner new-card-inner">
                <div class="plus-icon">
                    <div class="plus-horizontal"></div>
                    <div class="plus-vertical"></div>
                </div>
                <p class="new-card-text">Добавить новую задачу</p>
            </div>
        `;
    } else {
        const deadlineText = task.deadline 
            ? `До ${new Date(task.deadline).toLocaleDateString('ru-RU')}`
            : 'Дедлайн отсутствует';

        card.innerHTML = `
            <div class="card-inner">
                <div class="field-container">
                    <div class="task-field view-mode" data-field="title">${task.title || ''}</div>
                    <input class="task-input required edit-mode" data-field="title" placeholder="Название задачи" 
                           style="display:none;" value="${task.title || ''}">
                </div>
                <div class="field-container">
                    <div class="task-field view-mode description" data-field="description">${task.description || 'Описание отсутствует'}</div>
                    <textarea class="task-input edit-mode" data-field="description" placeholder="Описание задачи (необязательно)"
                              style="display:none;">${task.description || ''}</textarea>
                </div>
                <div class="field-container">
                    <div class="task-field view-mode" data-field="priority">Приоритет: ${task.priority}</div>
                    <select class="task-input edit-mode" data-field="priority" style="display:none;">
                        <option value="" disabled selected style="color: #9CA3AF;">
                            Выберите приоритет
                        </option>
                        <option value="Высокий" ${task.priority === 'Высокий' ? 'selected' : ''}>Высокий</option>
                        <option value="Средний" ${task.priority === 'Средний' ? 'selected' : ''}>Средний</option>
                        <option value="Низкий" ${task.priority === 'Низкий' ? 'selected' : ''}>Низкий</option>
                    </select>
                </div>
                <div class="field-container">
                    <div class="task-field view-mode" data-field="deadline">${deadlineText}</div>
                    <input type="date" class="task-input edit-mode" data-field="deadline" 
                           style="display:none;" value="${task.deadline ? task.deadline.split('T')[0] : ''}">
                </div>
                <div class="card-actions">
                    <button class="action-btn edit-btn">Редактировать</button>
                    <button class="action-btn delete-btn">Удалить</button>
                    <button class="action-btn save-btn" style="display:none;">Сохранить</button>
                    <button class="action-btn cancel-btn" style="display:none;">Отмена</button>
                </div>
            </div>
        `;
    }

    return card;
}

function setupTaskEvents() {
    const tasksGrid = document.getElementById('tasksGrid');
    const sortButtons = document.querySelectorAll('.sort-btn');
    
    if (tasksGrid) {
        tasksGrid.addEventListener('click', handleTaskCardClick);
    }
    
    if (sortButtons.length > 0) {
        sortButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                sortButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentSort = btn.dataset.sort;
                loadTasks();
            });
        });
    }
}

function handleTaskCardClick(event) {
    const card = event.target.closest('.task-card');
    if (!card) return;

    const taskId = card.dataset.id;

    if (card.classList.contains('new-task-card')) {
        createNewTask(card);
        return;
    }

    if (event.target.classList.contains('edit-btn')) {
        enableEditMode(card);
        return;
    }

    if (event.target.classList.contains('save-btn')) {
        saveTask(taskId, card);
        return;
    }

    if (event.target.classList.contains('cancel-btn')) {
        disableEditMode(card);
        loadTasks();
        return;
    }

    if (event.target.classList.contains('delete-btn')) {
        deleteTask(taskId);
        return;
    }
}

function enableEditMode(card) {
    card.querySelector('.card-inner').style.backgroundColor = '#FFFFFF';
    card.querySelectorAll('.view-mode').forEach(el => el.style.display = 'none');
    card.querySelectorAll('.edit-mode').forEach(el => el.style.display = 'block');
    card.querySelector('.edit-btn').style.display = 'none';
    card.querySelector('.delete-btn').style.display = 'none';
    card.querySelector('.save-btn').style.display = 'block';
    card.querySelector('.cancel-btn').style.display = 'block';
}

function disableEditMode(card) {
    card.querySelector('.card-inner').style.backgroundColor = '';
    card.querySelectorAll('.view-mode').forEach(el => el.style.display = 'block');
    card.querySelectorAll('.edit-mode').forEach(el => el.style.display = 'none');
    card.querySelector('.edit-btn').style.display = 'block';
    card.querySelector('.delete-btn').style.display = 'block';
    card.querySelector('.save-btn').style.display = 'none';
    card.querySelector('.cancel-btn').style.display = 'none';
}

function createNewTask(newCardElement) {
    const tempTask = { title: '', description: '', priority: 'Средний', deadline: '' };
    const editCard = createTaskCard(tempTask, false);
    editCard.querySelector('.card-inner').style.backgroundColor = '#FFFFFF';
    enableEditMode(editCard);
    newCardElement.replaceWith(editCard);
}

async function saveTask(taskId, card) {
    const title = card.querySelector('input[data-field="title"]')?.value.trim();
    const description = card.querySelector('textarea[data-field="description"]')?.value.trim();
    const priority = card.querySelector('select[data-field="priority"]')?.value;
    const deadline = card.querySelector('input[data-field="deadline"]')?.value || null;

    if (!title) {
        alert('Название задачи обязательно!');
        return;
    }
    if (!priority) {
        alert('Приоритет должен быть выбран!');
        return;
    }

    const taskData = {
        title,
        description: description || null,
        priority,
        deadline: deadline ? new Date(deadline).toISOString() : null
    };

    try {
        let response;
        if (taskId === 'new') {
            response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });
        } else {
            response = await fetch(`${API_URL}/${taskId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });
        }

        if (response.ok) {
            loadTasks();
        } else {
            throw new Error('Ошибка при сохранении');
        }
    } catch (error) {
        console.error('Ошибка сохранения:', error);
        alert('Не удалось сохранить задачу');
    }
}

async function deleteTask(taskId) {
    if (!confirm('Вы уверены, что хотите удалить эту задачу?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/${taskId}`, { method: 'DELETE' });
        
        if (response.ok) {
            loadTasks();
        } else {
            throw new Error('Ошибка при удалении');
        }
    } catch (error) {
        console.error('Ошибка удаления:', error);
        alert('Не удалось удалить задачу');
    }
}

// функция для имитации скачивания файла
function downloadFile(fileName) {
    const link = document.createElement('a');
    link.href = '#';
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    alert(`Начато скачивание файла: ${fileName}\n(В демо-версии файл не загружается)`);
}

// функция для проверки адаптивности
function checkResponsive() {
    const width = window.innerWidth;
    const footer = document.querySelector('.footer');
    
    if (width <= 1200 && footer) {
        footer.style.position = 'relative';
    }
}

// инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    console.log('Страница загружена. Инициализация...');
    
    loadData();
    setupTaskEvents();
    
    // Если на странице tasks, загружаем задачи
    if (window.location.pathname.includes('tasks.html') || window.location.pathname === '/tasks') {
        loadTasks();
    }
    
    checkResponsive();
    window.addEventListener('resize', checkResponsive);
    
    console.log('Все элементы настроены');
});

async function updateTasksPreview() {
    const container = document.getElementById('tasksPreview');
    if (!container) return;

    try {
        const res = await fetch('/api/tasks/latest');
        const tasks = await res.json();

        container.innerHTML = '';

        if (tasks.length === 0) {
            container.innerHTML = '<p>Задач пока нет</p>';
            return;
        }

        tasks.forEach(task => {
            const card = document.createElement('div');
            card.className = 'task-card';

            card.innerHTML = `
                <h3>${task.title}</h3>
                ${task.description ? `<p>${task.description}</p>` : ''}
                ${task.deadline ? `<span>До: ${new Date(task.deadline).toLocaleDateString()}</span>` : ''}
            `;

            container.appendChild(card);
        });

    } catch (e) {
        console.error(e);
        container.innerHTML = '<p>Ошибка загрузки задач</p>';
    }
}

