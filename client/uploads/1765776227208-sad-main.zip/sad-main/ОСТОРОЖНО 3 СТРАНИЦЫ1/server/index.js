// index.js
const express = require('express');
const cors = require('cors');
const path = require('path');
const { Sequelize, DataTypes } = require('sequelize');
const multer = require('multer');
const fs = require('fs');

const app = express();
const PORT = 3000;

/* =======================
   Middleware
======================= */
app.use(cors());
app.use(express.json());
app.use('/api', (req, res, next) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    next();
});


/* =======================
   Пути
======================= */
const clientPath = path.join(__dirname, '..', 'client');

/* =======================
   Статика
======================= */
app.use(express.static(clientPath));

/* =======================
   База данных
======================= */
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: path.join(__dirname, '..', 'database.db'),
    logging: false
});

const Task = sequelize.define('Task', {
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    priority: {
        type: DataTypes.STRING,
        defaultValue: 'Средний'
    },
    deadline: {
        type: DataTypes.DATE,
        allowNull: true
    }
}, {
    timestamps: true
});

const Document = sequelize.define('Document', {
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    fileName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    fileType: {
        type: DataTypes.STRING,
        allowNull: false
    },
    uploadDate: {
        type: DataTypes.DATE,
        defaultValue: Sequelize.NOW
    },
    filePath: {
        type: DataTypes.STRING,
        allowNull: false
    }
}, {
    timestamps: true
});

sequelize.sync().then(() => {
    console.log('✓ База данных готова');
});

/* =======================
   Загрузка файлов
======================= */
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, '..', 'client', 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const originalNameUtf8 =
            Buffer.from(file.originalname, 'latin1').toString('utf8');

        const uniqueName = Date.now() + '-' + originalNameUtf8;
        cb(null, uniqueName);
    }

});

const upload = multer({ storage: storage });

/* =======================
   API для задач
======================= */
app.get('/api/tasks', async (req, res) => {
    const { sortBy } = req.query;

    let order = [['createdAt', 'DESC']];

    if (sortBy === 'old') {
        order = [['createdAt', 'ASC']];
    }

    if (sortBy === 'deadline') {
        order = [['deadline', 'ASC']];
    }

    if (sortBy === 'priority') {
        order = [[
            sequelize.literal(`
                CASE priority
                    WHEN 'Высокий' THEN 3
                    WHEN 'Средний' THEN 2
                    WHEN 'Низкий' THEN 1
                    ELSE 0
                END
            `),
            'DESC'
        ]];
    }

    const tasks = await Task.findAll({ order });
    res.json(tasks);
});

app.post('/api/tasks', async (req, res) => {
    try {
        const task = await Task.create(req.body);
        res.status(201).json(task);
    } catch (e) {
        res.status(400).json({ error: 'Ошибка создания задачи' });
    }
});

app.put('/api/tasks/:id', async (req, res) => {
    const task = await Task.findByPk(req.params.id);
    if (!task) {
        return res.status(404).json({ error: 'Задача не найдена' });
    }

    await task.update(req.body);
    res.json(task);
});

app.delete('/api/tasks/:id', async (req, res) => {
    const task = await Task.findByPk(req.params.id);
    if (!task) {
        return res.status(404).json({ error: 'Задача не найдена' });
    }

    await task.destroy();
    res.json({ success: true });
});

/* =======================
   API для документов
======================= */

// Загрузка файла
app.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'Файл не загружен' });
    }
    res.json({ fileName: req.file.filename });
});

// Скачивание файла
app.get('/download/:fileName', (req, res) => {
    const filePath = path.join(__dirname, '..', 'client', 'uploads', req.params.fileName);
    if (fs.existsSync(filePath)) {
        res.download(filePath);
    } else {
        res.status(404).json({ error: 'Файл не найден' });
    }
});

// Получение документа по ID
app.get('/api/documents/:id', async (req, res) => {
    try {
        const document = await Document.findByPk(req.params.id);
        if (!document) {
            return res.status(404).json({ error: 'Документ не найден' });
        }
        res.json(document);
    } catch (e) {
        console.error(e);
        res.status(400).json({ error: 'Ошибка получения документа' });
    }
});

// Получение всех документов с сортировкой
app.get('/api/documents', async (req, res) => {
    try {
        const { sortBy } = req.query;

        let order = [['createdAt', 'DESC']];

        // сортировка по имени
        if (sortBy === 'name') {
            order = [['name', 'ASC']];
        }

        // сортировка по типу файла
        if (['pdf', 'doc', 'docx', 'xls', 'png', 'jpeg'].includes(sortBy)) {
            order = [
                [
                    sequelize.literal(`
                        CASE
                            WHEN fileType = '${sortBy.toUpperCase()}' THEN 0
                            WHEN fileType = 'DOC'  THEN 1
                            WHEN fileType = 'DOCX' THEN 2
                            WHEN fileType = 'PDF'  THEN 3
                            WHEN fileType = 'XLS'  THEN 4
                            WHEN fileType = 'PNG'  THEN 5
                            WHEN fileType = 'JPEG' THEN 6
                            ELSE 7
                        END
                    `),
                    'ASC'
                ],
                ['createdAt', 'DESC']
            ];
        }

        const documents = await Document.findAll({ order });
        res.json(documents);
    } catch (e) {
        console.error(e);
        res.status(400).json({ error: 'Ошибка получения документов' });
    }
});


// Создание документа с поддержкой кириллицы
app.post('/api/documents', async (req, res) => {
    try {
        // Берём данные из формы
        let { name, fileName, fileType, filePath } = req.body;

        // Обеспечиваем корректную кодировку UTF-8
        if (typeof name === 'string') {
            name = name.trim(); // убираем лишние пробелы
            name = name.normalize('NFC'); // нормализуем Unicode
        }

        if (typeof fileName === 'string') {
            fileName = fileName.trim();
            fileName = fileName.normalize('NFC');
        }

        // Создаём запись в базе
        const document = await Document.create({
            name,
            fileName,
            fileType,
            filePath,
            uploadDate: new Date()
        });

        res.status(201).json(document);
    } catch (e) {
        console.error(e);
        res.status(400).json({ error: 'Ошибка создания документа' });
    }
});


// Обновление документа
app.put('/api/documents/:id', async (req, res) => {
    try {
        const document = await Document.findByPk(req.params.id);
        if (!document) {
            return res.status(404).json({ error: 'Документ не найден' });
        }

        await document.update(req.body);
        res.json(document);
    } catch (e) {
        console.error(e);
        res.status(400).json({ error: 'Ошибка обновления документа' });
    }
});

// Удаление документа
app.delete('/api/documents/:id', async (req, res) => {
    try {
        const document = await Document.findByPk(req.params.id);
        if (!document) {
            return res.status(404).json({ error: 'Документ не найден' });
        }

        // Удаляем файл с диска
        const filePath = path.join(__dirname, '..', 'client', document.filePath);
        
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }

        await document.destroy();
        res.json({ success: true });
    } catch (e) {
        console.error(e);
        res.status(400).json({ error: 'Ошибка удаления документа' });
    }
});

/* =======================
   Страницы
======================= */
app.get('/', (req, res) => {
    res.sendFile(path.join(clientPath, 'index.html'));
});

app.get('/tasks', (req, res) => {
    res.sendFile(path.join(clientPath, 'tasks.html'));
});

app.get('/documents', (req, res) => {
    res.sendFile(path.join(clientPath, 'documents.html'));
});

/* =======================
   404
======================= */
app.use((req, res) => {
    res.status(404).json({ error: 'Маршрут не найден' });
});

/* =======================
   Start
======================= */
app.listen(PORT, () => {
    console.log('=================================');
    console.log('🚀 Сервер запущен');
    console.log(`🌐 http://localhost:${PORT}`);
    console.log('=================================');
});